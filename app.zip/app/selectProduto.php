<?php
    include_once('conexao.php.php');
    class Categorias{
        
        
        public function catego(){
            $conect = new cnx;
            $cnx = $conect->conect();
            return mysqli_query($cnx,"select categoria from categoria");
        }
    }
    $cat = new Categorias;
    $resultado = $cat->catego();

?>
