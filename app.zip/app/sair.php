<?php

session_start();
session_destroy();
unset($_SESSION['usuarioId']);
unset($_SESSION['usuarioEmail']);
unset($_SESSION['usuarioNome']);
unset($_SESSION['usuarioTelefone']);
unset($_SESSION['usuarioPrivilegio']);

$_SESSION['usuarioId'] = null;
$_SESSION['usuarioEmail'] = null;
$_SESSION['usuarioNome'] = null;
$_SESSION['usuarioTelefone'] = null;
$_SESSION['usuarioPrivilegio'] = null;
 $id = null;
 $email = null;
 $nome = null;
 $telefone = null;
 $privilegio = null;
 session_commit();
header('Location: ../login.php');



?>