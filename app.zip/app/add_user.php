<?php
include_once('conexao.php');

class addUser{

    private string $nome,$email,$telefone,$pwd,$pwd2;
    public function add(string $nome1, string $email1, string $tel1, string $pwd1, string $pwd21){
        $conectar = new cnx;
        $cnxF = $conectar->conect();

        $this->nome = $nome1 ;
        $this->email = $email1;
        $this->telefone = $tel1;
        $this->pwd = $pwd1;
        $this->pwd2 = $pwd21;

        if(strcmp($this->pwd,$this->pwd2) == 0){
            mysqli_query($cnxF,"insert into usuario values(default,'$this->nome','$this->email',' $this->telefone','$this->pwd',default)");
            header('Location:  ../login.php?info=sucesso');
        }else{
            header('Location: ../login.php?info=error');
        }

    }
}

$adicionar = new addUser;
$adicionar->add($_POST['nome'], $_POST['email'], $_POST['telefone'],  $_POST['password'],  $_POST['password2']);

?>