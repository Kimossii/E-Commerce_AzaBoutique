<?php
include_once('conexao.php');

if(!isset($_POST)); header('Location: ../login.php');

class VerificarUsuario{
    private string $comando;
    public function Verificar(string $email, string $password){

        $conect = new cnx;
        $this->comando = "select *from usuario where email='$email' and passe='$password' limit 1 ";
        $result = mysqli_query( $conect->conect(),$this->comando) or die ();

        if((mysqli_num_rows($result)) < 1 ){
            header('Location: ../login.php');
        }else{
        
            $dados = mysqli_fetch_assoc($result);
            //VERIFICAR SE EXISTE UMA SESSAO
            if(!isset($_SESSION))  session_start();
              
                //INICIAR UMA SESSAO
                $_SESSION['usuarioId'] = $dados['id_usuario'];
                $_SESSION['usuarioNome'] =$dados['nome'];
                $_SESSION['usuarioEmail'] = $dados['email'];
                $_SESSION['usuarioTelefone'] = $dados['telefone'];
                $_SESSION['usuarioPrivilegio']=$dados['privilegio'];
        
                if($_SESSION['usuarioPrivilegio'] == 1){
                    header('Location: ../index.php');
                }else{
                    header('Location: ../admin/index.php');
                }
            }
    } 
}

$verific = new VerificarUsuario;
$verific->Verificar($_POST['EMAIL'], $_POST['PASSWORD']);

?>

