<?php
    include_once('conexao.php');
   // include_once('cnx.php');

    
    class clientes {

       
        private string $cmd_final;
        
        public function resultado( ){
               $conectar = new cnx;
               $cnx = $conectar->conect();

               return mysqli_query($cnx,"select id_usuario, nome,email,telefone,privilegio from usuario");
            }
    }
    $res = new clientes;
    $resultado = $res->resultado();
        
?>