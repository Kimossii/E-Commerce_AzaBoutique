<?php
if(!$_SESSION) {header("Location: ../index.php");
  if(!$privilegio != 0){
    header("Location: ../index.php");
  }
}
?>