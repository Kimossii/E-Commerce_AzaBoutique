<?php

class cnx{    

    public function conect(){
        return mysqli_connect("127.0.0.1","root","","azaboutique");
    }
}
$conectar = new cnx;
$cnx = $conectar->conect();
?>