<?php
 include_once('conexao.php');
 include_once('gravar_verificacao.php');
        class pedidos {

       
        private string $cmd_final;
        
        public function listarPedidos( int $id ){
            $id1 = $id;
               $conectar = new cnx;
               $cnx = $conectar->conect();

               return mysqli_query($cnx,"select *from cliente where id= '$id1'");
            }
            
    }   
    $res = new pedidos;
    $listarPedidos = $res->listarPedidos($_SESSION['usuarioId']);

        
?>