<?php

        include_once('conexao.php');
        include_once('gravar_verificacao.php');
            if(!isset($_POST)){
            header("Location: ../admin/login.php"); exit;
        }

        class DellBanner{
            private int $id;

            public function dell(int $id){
            $this->id = $id;

            $conect = new cnx();
            $cnx = $conect->conect();
            mysqli_query($cnx,"delete from banner where id = ".$this->id."");
            header("Location: ../admin/index_banner.php?acao=sucess"); 
            
        }
       
    }

    $delBanner = new DellBanner;
    $delBanner->dell($_GET['id']); 


?>