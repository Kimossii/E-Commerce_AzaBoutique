<?php

    $result = mysqli_query($cnx,"select id, nome,email,permissao from usuarios");

?>
