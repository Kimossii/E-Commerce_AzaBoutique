<?php

if(!isset($_SESSION)) session_start();

if(!isset($_SESSION['usuarioId'])){session_destroy();}

if(!$_SESSION){}
   else{ 
    $id = $_SESSION['usuarioId'];
    $nome = $_SESSION['usuarioNome'];
    $email = $_SESSION['usuarioEmail'];
    //$telefone = $_SESSION('usuarioTelefone');
    $privilegio = $_SESSION['usuarioPrivilegio'];}



?>