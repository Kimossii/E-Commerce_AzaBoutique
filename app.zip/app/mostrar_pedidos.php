<?php
include_once('../app/conexao.php');

$pReoetidos="";
$qtdconta = 0;
$result = mysqli_query($c nx, "select *from cliente");

$resultTotal = mysqli_query($cnx, "select sum(total) as tot from cliente");
$TotalValor = mysqli_fetch_assoc($resultTotal);
$TotalVendido = number_format($TotalValor['tot'],2,',','.');

class PedidoFavorito
{
   
    public function mostrar()
    {
      $conect = new cnx;
      $cnx = $conect->conect();
      $pReoetidos = "";
      $qtdconta = 0;
        $Gfavorito = "";
        $cont = 0;
      
        $result = mysqli_query($cnx, "select *from cliente");

        while ($dados = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            
            $pReoetidos .="," .$dados['produtos'];  
            }
            $qtdsProduto = explode(',', $pReoetidos);
            
           
            $qtdFavorito = array_count_values($qtdsProduto); // 2
            foreach ($qtdFavorito  as $key => $value) {

                # code...
               
                if ($cont != 0) {
                    # code...
                    if ($value > $qtdconta ) {
                        $qtdconta = $value;
                        $Gfavorito = $key;
                        # code...
                    }
                }
                $cont++;
            } 
            
            return $Gfavorito ;
        }
        

       
    }
    

$favorito = new PedidoFavorito;
$Nfavorito = $favorito->mostrar();

//$Nfavorito = array_count_values($afavorito);
?>