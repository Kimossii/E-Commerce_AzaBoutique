<?php
include_once('conexao.php');
include_once('gravar_verificacao.php');

if(!isset($_POST)){
    header("Location: ../admin/login.php"); exit;}

    class excluirUsuarios{
        private int $id;

        public function dellUsuarios (int $id){
            $this->id = $id;
            $conect = new cnx;
            $cnx = $conect->conect();

            $cmd = "delete from usuario where id_usuario =$this->id";

        return mysqli_query($cnx,$cmd);
    }
    }
    $dell = new excluirUsuarios;
    $dell->dellUsuarios($_POST['id']);
    header("Location: ../admin/listar_clientes.php?info=dellSucess");


?>