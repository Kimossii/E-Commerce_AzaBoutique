<?php
 include_once('conexao.php');
 include_once('../app/gravar_verificacao.php');
        class contarPedidos {

       
        private string $cmd_final;
        
        public function resultado3( ){
               $conectar = new cnx;
               $cnx = $conectar->conect();

               return mysqli_query($cnx,"select *from cliente");
            }
            
    }   
    $res = new contarPedidos;
    $resultado3 = $res->resultado3();
        
?>