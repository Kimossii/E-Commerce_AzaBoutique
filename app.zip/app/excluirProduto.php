<?php

include_once('conexao.php');
    include_once('gravar_verificacao.php');
     if(!isset($_POST)){
        header("Location: ../admin/login.php"); exit;}

        class excluirProduto{

            private int $id;

            public function dellProduto (int $id){
            $this->id = $id;
            $conect = new cnx;
            $cnx = $conect->conect();

            $cmd = "delete from produtos where id =$this->id";

        return mysqli_query($cnx,$cmd);
    }    
}

$dell = new excluirProduto;
$dell->dellProduto($_POST['id']);
header("Location: ../admin/index.php?info=dellSucess");

?>