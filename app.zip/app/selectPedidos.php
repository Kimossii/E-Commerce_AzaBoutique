<?php
 include_once('conexao.php');
 include_once('../app/gravar_verificacao.php');
        class pedidos {

       
        private string $cmd_final;
        
        public function resultado( ){
               $conectar = new cnx;
               $cnx = $conectar->conect();

               return mysqli_query($cnx,"select *from cliente");
            }
        public function valorArrecadado(){
                $conectar = new cnx;
                $cnx = $conectar->conect();

                return mysqli_query($cnx, "select sum(total) as tota from cliente");
        }    
    }   
    $res = new pedidos;
    $resultado1 = $res->resultado();
    $resultado2 = $res->valorArrecadado(); 
        
?>